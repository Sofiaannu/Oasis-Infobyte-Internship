arr=[8,7,6,5,9,3]
arr.sort()
print(arr)